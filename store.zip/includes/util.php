<?php
// includes/util.php

function format_price(int|float $amount): string {
    return 'Rp ' . number_format($amount, 0, ',', '.');
}

function flash_set(string $key, string $msg): void {
    $_SESSION['flash'][$key] = $msg;
}

function flash_get(string $key): ?string {
    if (!empty($_SESSION['flash'][$key])) {
        $m = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $m;
    }
    return null;
}

/**
 * Convert a string to a URL-friendly slug
 */
function slugify(string $text): string {
    $text = strtolower($text);
    $text = preg_replace('~[^a-z0-9]+~', '-', $text);
    $text = trim($text, '-');
    return $text ?: 'produk';
}

/**
 * Build SEO-friendly product URL: /store/p/{id}-{slug}
 */
function product_url(int $id, string $title = ''): string {
    $slug = slugify($title);
    return base_url('p/' . $id . '-' . $slug);
}
